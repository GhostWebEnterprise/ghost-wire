//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DGgc3Gcw.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/api/rtc"],
		preloads: ["/assets/index-C1pz5g1T.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C1pz5g1T.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Dh45JQ70.js"]
	}
} });
//#endregion
export { tsrStartManifest };
