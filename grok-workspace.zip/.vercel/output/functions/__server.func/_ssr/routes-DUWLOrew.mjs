import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { r as Slot, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { A as ArrowLeft, C as Inbox, D as Clock, E as Copy, O as Check, S as Info, T as Fingerprint, _ as PhoneOff, a as VideoOff, b as MicOff, c as Shield, d as Settings, f as Send, g as Phone, h as Plus, i as Video, j as Archive, k as Battery, l as ShieldQuestion, m as Radio, n as X, p as Search, r as Wifi, s as Timer, t as Zap, u as ShieldAlert, v as Paperclip, w as Flag, x as Lock, y as Mic } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle, r as DialogContent$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as Trigger, i as Root2, n as Item2, r as Portal2, t as Content2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
import { t as Provider } from "../_libs/radix-ui__react-tooltip.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DUWLOrew.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var TIME = new Intl.DateTimeFormat(void 0, {
	hour: "2-digit",
	minute: "2-digit"
});
var DAY = new Intl.DateTimeFormat(void 0, {
	month: "short",
	day: "numeric"
});
function formatTime(at) {
	return TIME.format(at);
}
function formatListTime(at) {
	const diff = Date.now() - at;
	if (diff < 6e4) return "now";
	if (diff < 864e5 && new Date(at).getDate() === (/* @__PURE__ */ new Date()).getDate()) return TIME.format(at);
	if (diff < 6048e5) return new Intl.DateTimeFormat(void 0, { weekday: "short" }).format(at);
	return DAY.format(at);
}
function formatDuration(ms) {
	const s = Math.max(0, Math.floor(ms / 1e3));
	const m = Math.floor(s / 60);
	const h = Math.floor(m / 60);
	const mm = String(m % 60).padStart(2, "0");
	const ss = String(s % 60).padStart(2, "0");
	return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}
function ttlLabel(hours) {
	if (hours === 0) return "Keep";
	if (hours === 1) return "1h";
	if (hours === 24) return "24h";
	if (hours === 72) return "72h";
	return `${hours}h`;
}
function initials(name) {
	const parts = name.trim().split(/\s+/).filter(Boolean);
	if (parts.length === 0) return "GW";
	if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
	return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}
var hues = [
	"bg-avatar-1",
	"bg-avatar-2",
	"bg-avatar-3",
	"bg-avatar-4",
	"bg-avatar-5",
	"bg-avatar-6"
];
function GhostMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("text-accent", className),
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "16",
				r: "11.5",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M16 7.5v6.5M16 18v6.5M7.5 16h6.5M18 16h6.5",
				stroke: "currentColor",
				strokeWidth: "1.4",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "16",
				r: "2.2",
				fill: "currentColor"
			})
		]
	});
}
function PersonMark({ name, hue, size = "md", verified }) {
	const dim = size === "sm" ? "size-8 text-[10px]" : size === "lg" ? "size-14 text-base" : "size-10 text-xs";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "relative inline-flex shrink-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("inline-flex items-center justify-center rounded-full font-medium tracking-wide text-fg", hues[hue % hues.length], dim),
			children: initials(name)
		}), verified ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -bottom-0.5 -right-0.5 size-3 rounded-full bg-verified ring-2 ring-bg" }) : null]
	});
}
var te = new TextEncoder();
var td = new TextDecoder();
function bytesToB64(bytes) {
	let s = "";
	for (const b of bytes) s += String.fromCharCode(b);
	return btoa(s);
}
function b64ToBytes(b64) {
	const s = atob(b64);
	const out = new Uint8Array(s.length);
	for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
	return out;
}
function bufToB64(buf) {
	return bytesToB64(new Uint8Array(buf));
}
function randomId(prefix = "id") {
	return `${prefix}_${bytesToB64(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(8))).replace(/[+/=]/g, "").slice(0, 12)}`;
}
function formatFingerprint(hex) {
	return hex.replace(/[^0-9a-f]/gi, "").toUpperCase().slice(0, 32).replace(/(.{4})/g, "$1 ").trim();
}
async function sha256Hex(data) {
	const digest = await crypto.subtle.digest("SHA-256", data);
	return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function generateIdentity() {
	const pair = await crypto.subtle.generateKey({
		name: "ECDSA",
		namedCurve: "P-256"
	}, true, ["sign", "verify"]);
	const publicJwk = await crypto.subtle.exportKey("jwk", pair.publicKey);
	const privateJwk = await crypto.subtle.exportKey("jwk", pair.privateKey);
	const hex = await sha256Hex(te.encode(`${publicJwk.x}.${publicJwk.y}`));
	return {
		id: `op_${hex.slice(0, 10)}`,
		fingerprint: formatFingerprint(hex),
		publicJwk,
		privateJwk
	};
}
async function pbkdf2Key(secret, salt, usages) {
	const base = await crypto.subtle.importKey("raw", te.encode(secret), "PBKDF2", false, ["deriveKey"]);
	return crypto.subtle.deriveKey({
		name: "PBKDF2",
		salt,
		iterations: 8e4,
		hash: "SHA-256"
	}, base, {
		name: "AES-GCM",
		length: 256
	}, false, usages);
}
async function pinHash(pin, saltB64) {
	const salt = saltB64 ? b64ToBytes(saltB64) : crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(16));
	const base = await crypto.subtle.importKey("raw", te.encode(pin), "PBKDF2", false, ["deriveBits"]);
	const bits = await crypto.subtle.deriveBits({
		name: "PBKDF2",
		salt,
		iterations: 8e4,
		hash: "SHA-256"
	}, base, 256);
	return {
		salt: bytesToB64(salt),
		hash: bufToB64(bits)
	};
}
async function wrapJson(pin, data) {
	const salt = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(16));
	const iv = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(12));
	const key = await pbkdf2Key(pin, salt, ["encrypt"]);
	const ct = await crypto.subtle.encrypt({
		name: "AES-GCM",
		iv
	}, key, te.encode(JSON.stringify(data)));
	return JSON.stringify({
		v: 1,
		salt: bytesToB64(salt),
		iv: bytesToB64(iv),
		ct: bufToB64(ct)
	});
}
async function unwrapJson(pin, blob) {
	const parsed = JSON.parse(blob);
	const key = await pbkdf2Key(pin, b64ToBytes(parsed.salt), ["decrypt"]);
	const pt = await crypto.subtle.decrypt({
		name: "AES-GCM",
		iv: b64ToBytes(parsed.iv)
	}, key, b64ToBytes(parsed.ct));
	return JSON.parse(td.decode(pt));
}
async function deriveRoomKey(code) {
	const salt = te.encode("ghostwire-room-v1");
	const base = await crypto.subtle.importKey("raw", te.encode(code.toLowerCase()), "PBKDF2", false, ["deriveKey"]);
	return crypto.subtle.deriveKey({
		name: "PBKDF2",
		salt,
		iterations: 5e4,
		hash: "SHA-256"
	}, base, {
		name: "AES-GCM",
		length: 256
	}, false, ["encrypt", "decrypt"]);
}
async function encryptText(key, plaintext) {
	const iv = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(12));
	const ct = await crypto.subtle.encrypt({
		name: "AES-GCM",
		iv
	}, key, te.encode(plaintext));
	return `${bytesToB64(iv)}.${bufToB64(ct)}`;
}
async function decryptText(key, payload) {
	const [ivB64, ctB64] = payload.split(".");
	if (!ivB64 || !ctB64) throw new Error("malformed payload");
	const pt = await crypto.subtle.decrypt({
		name: "AES-GCM",
		iv: b64ToBytes(ivB64)
	}, key, b64ToBytes(ctB64));
	return td.decode(pt);
}
function generateInviteCode() {
	const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
	const bytes = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(8));
	let out = "";
	for (const b of bytes) out += alphabet[b % 32];
	return `GW-${out.slice(0, 4)}-${out.slice(4)}`;
}
function roomIdFromCode(code) {
	return code.replace(/[^a-zA-Z0-9]/g, "").toLowerCase().slice(0, 64);
}
function displayCode(code) {
	const compact = code.replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
	if (compact.startsWith("GW") && compact.length >= 10) return `GW-${compact.slice(2, 6)}-${compact.slice(6, 10)}`;
	return compact;
}
var HOUR = 36e5;
function fp(seed) {
	return {
		calder: "A91C 4E20 7B6D 11F8 93AA 0C44 51D2 6E7B",
		voss: "3F18 90BB 2C71 44AE 19D0 6A55 88C3 01F2",
		ops: "C0DE 12AB 9F44 70E1 55AA 2190 B3C8 4D6E",
		relay: "1111 8E2A 90CC 44D1 77AB 02F9 3C10 6AA1",
		notes: "BEEF 0144 90AA 33C1 78D2 6E01 4F19 A3C0"
	}[seed] ?? "0000 0000 0000 0000 0000 0000 0000 0000";
}
var defaultSettings = () => ({
	screenshotShield: true,
	stealth: true,
	coverTraffic: true,
	readReceipts: false,
	defaultTtl: 72,
	autoLockMinutes: 0
});
function buildSeed(identity) {
	const now = Date.now();
	const you = {
		id: identity.id,
		name: identity.callsign,
		fingerprint: identity.fingerprint,
		verified: true,
		hue: 0,
		role: "admin"
	};
	const calder = {
		id: "p-calder",
		name: "N. Calder",
		fingerprint: fp("calder"),
		verified: true,
		hue: 1,
		role: "member"
	};
	const voss = {
		id: "p-voss",
		name: "A. Voss",
		fingerprint: fp("voss"),
		verified: false,
		hue: 2,
		role: "member"
	};
	const relay = {
		id: "p-relay",
		name: "Relay",
		fingerprint: fp("relay"),
		verified: true,
		hue: 3,
		role: "member"
	};
	const kirk = {
		id: "p-kirk",
		name: "M. Kirk",
		fingerprint: "77AA 12C0 90E1 44B2 19D8 6F03 2A11 C4E9",
		verified: true,
		hue: 4,
		role: "member"
	};
	const conversations = [
		{
			id: "c-ops",
			kind: "group",
			title: "GhostWeb Ops",
			subtitle: "MLS · 4 members · PQ ratchet",
			hue: 3,
			verified: true,
			muted: false,
			archived: false,
			pinned: true,
			unread: 0,
			ttlHours: 72,
			lastAt: now - 72e4,
			lastPreview: "I'll send it sealed. No receipts.",
			members: [
				you,
				calder,
				voss,
				kirk
			]
		},
		{
			id: "c-calder",
			kind: "direct",
			title: "N. Calder",
			subtitle: "Verified · last hop 40ms",
			hue: 1,
			verified: true,
			muted: false,
			archived: false,
			pinned: false,
			unread: 1,
			ttlHours: 24,
			lastAt: now - 24e4,
			lastPreview: "Keys rotated. You're clear to drop.",
			members: [you, calder]
		},
		{
			id: "c-drop",
			kind: "dead-drop",
			title: "Dead drop",
			subtitle: "One-shot · no sender copy",
			hue: 5,
			verified: true,
			muted: false,
			archived: false,
			pinned: false,
			unread: 1,
			ttlHours: 24,
			lastAt: now - 3e6,
			lastPreview: "Sealed packet waiting",
			members: [you, relay]
		},
		{
			id: "c-voss",
			kind: "direct",
			title: "A. Voss",
			subtitle: "Unverified fingerprint",
			hue: 2,
			verified: false,
			muted: false,
			archived: false,
			pinned: false,
			unread: 0,
			ttlHours: 1,
			lastAt: now - 5 * HOUR,
			lastPreview: "Can you confirm the Berlin window?",
			members: [you, voss]
		},
		{
			id: "c-notes",
			kind: "direct",
			title: "Fork notes",
			subtitle: "Independent Android fork",
			hue: 6,
			verified: true,
			muted: false,
			archived: false,
			pinned: false,
			unread: 0,
			ttlHours: 0,
			lastAt: now - 26 * HOUR,
			lastPreview: "What GhostWire hardens over Wire Android.",
			members: [you, {
				id: "p-notes",
				name: "Vault",
				fingerprint: fp("notes"),
				verified: true,
				hue: 6
			}]
		}
	];
	const msg = (partial) => ({
		delivered: true,
		...partial
	});
	return {
		conversations,
		messages: {
			"c-ops": [
				msg({
					id: "m-ops-0",
					conversationId: "c-ops",
					kind: "system",
					fromId: "system",
					fromName: "Vault",
					body: "MLS group established · hybrid X25519 + ML-KEM-768 · epoch 14",
					at: now - 8 * HOUR,
					ttlHours: 0
				}),
				msg({
					id: "m-ops-1",
					conversationId: "c-ops",
					kind: "text",
					fromId: calder.id,
					fromName: calder.name,
					body: "Vault rotation complete on EU-West. Old epoch keys zeroized.",
					at: now - 3 * HOUR,
					ttlHours: 72
				}),
				msg({
					id: "m-ops-2",
					conversationId: "c-ops",
					kind: "text",
					fromId: identity.id,
					fromName: identity.callsign,
					body: "Confirmed. Cover profile stays diurnal until Friday.",
					at: now - 3 * HOUR + 24e4,
					ttlHours: 72,
					mine: true,
					reaction: "ack"
				}),
				msg({
					id: "m-ops-3",
					conversationId: "c-ops",
					kind: "text",
					fromId: kirk.id,
					fromName: kirk.name,
					body: "Relay is holding ciphertext only. Retention 72h, then purge.",
					at: now - 24e5,
					ttlHours: 72
				}),
				msg({
					id: "m-ops-4",
					conversationId: "c-ops",
					kind: "text",
					fromId: voss.id,
					fromName: voss.name,
					body: "Berlin dead-drop window is 72 hours. I'll keep the packet sealed.",
					at: now - 108e4,
					ttlHours: 72
				}),
				msg({
					id: "m-ops-5",
					conversationId: "c-ops",
					kind: "text",
					fromId: identity.id,
					fromName: identity.callsign,
					body: "I'll send it sealed. No receipts.",
					at: now - 72e4,
					ttlHours: 72,
					mine: true
				})
			],
			"c-calder": [
				msg({
					id: "m-ca-0",
					conversationId: "c-calder",
					kind: "system",
					fromId: "system",
					fromName: "Vault",
					body: "Fingerprints matched · session sealed",
					at: now - 48 * HOUR,
					ttlHours: 0
				}),
				msg({
					id: "m-ca-1",
					conversationId: "c-calder",
					kind: "text",
					fromId: calder.id,
					fromName: calder.name,
					body: "Don't put the handover in the group. Use a drop.",
					at: now - 33e5,
					ttlHours: 24
				}),
				msg({
					id: "m-ca-2",
					conversationId: "c-calder",
					kind: "text",
					fromId: identity.id,
					fromName: identity.callsign,
					body: "Understood. Timer 24h, sealed sender, no read receipts.",
					at: now - 3e6,
					ttlHours: 24,
					mine: true
				}),
				msg({
					id: "m-ca-3",
					conversationId: "c-calder",
					kind: "text",
					fromId: calder.id,
					fromName: calder.name,
					body: "Keys rotated. You're clear to drop.",
					at: now - 24e4,
					ttlHours: 24
				})
			],
			"c-drop": [
				msg({
					id: "m-dr-0",
					conversationId: "c-drop",
					kind: "system",
					fromId: "system",
					fromName: "Vault",
					body: "Dead drops are consumed once. The sender keeps a delivery marker, never the body.",
					at: now - 6 * HOUR,
					ttlHours: 0
				}),
				msg({
					id: "m-dr-1",
					conversationId: "c-drop",
					kind: "dead-drop",
					fromId: relay.id,
					fromName: relay.name,
					body: "BERLIN-NODE · pickup after 21:00 · ignore if the seal is broken",
					at: now - 3e6,
					ttlHours: 24,
					expiresAt: now + 23 * HOUR,
					sealed: true,
					consumed: false
				}),
				msg({
					id: "m-dr-2",
					conversationId: "c-drop",
					kind: "dead-drop",
					fromId: identity.id,
					fromName: identity.callsign,
					body: "",
					at: now - 3 * HOUR,
					ttlHours: 1,
					sealed: false,
					consumed: true,
					mine: true
				})
			],
			"c-voss": [
				msg({
					id: "m-vo-0",
					conversationId: "c-voss",
					kind: "system",
					fromId: "system",
					fromName: "Vault",
					body: "Safety number not verified. Compare fingerprints in person before sensitive traffic.",
					at: now - 30 * HOUR,
					ttlHours: 0
				}),
				msg({
					id: "m-vo-1",
					conversationId: "c-voss",
					kind: "text",
					fromId: voss.id,
					fromName: voss.name,
					body: "Can you confirm the Berlin window?",
					at: now - 5 * HOUR,
					ttlHours: 1,
					expiresAt: now + 12e5
				}),
				msg({
					id: "m-vo-2",
					conversationId: "c-voss",
					kind: "text",
					fromId: identity.id,
					fromName: identity.callsign,
					body: "Not on this channel. I'll verify your fingerprint first.",
					at: now - 5 * HOUR + 36e4,
					ttlHours: 1,
					mine: true
				})
			],
			"c-notes": [
				msg({
					id: "m-no-0",
					conversationId: "c-notes",
					kind: "system",
					fromId: "system",
					fromName: "Vault",
					body: "Local briefing · nothing here leaves the device",
					at: now - 26 * HOUR,
					ttlHours: 0
				}),
				msg({
					id: "m-no-1",
					conversationId: "c-notes",
					kind: "text",
					fromId: "p-notes",
					fromName: "Vault",
					body: "GhostWire is an independent Android client in the Wire protocol lineage. Package app.ghostwire. It does not connect to Wire Swiss servers and is not affiliated with Wire Swiss GmbH.",
					at: now - 26 * HOUR + 1e3,
					ttlHours: 0
				}),
				msg({
					id: "m-no-2",
					conversationId: "c-notes",
					kind: "text",
					fromId: "p-notes",
					fromName: "Vault",
					body: "Hardened vs stock Wire Android: zero identity, hybrid PQ (ML-KEM-768 + X25519), dead drops, duress PIN wipe, screenshot shield, stealth (no last-seen), no Google Play Services, sealed P2P invite channels.",
					at: now - 26 * HOUR + 2e3,
					ttlHours: 0
				}),
				msg({
					id: "m-no-3",
					conversationId: "c-notes",
					kind: "text",
					fromId: "p-notes",
					fromName: "Vault",
					body: "Set a vault PIN and a second duress PIN in Vault. Built for GrapheneOS. The duress PIN destroys keys, messages, and contacts with no recovery.",
					at: now - 26 * HOUR + 3e3,
					ttlHours: 0
				})
			]
		}
	};
}
var demoDevices = [
	{
		id: "d-here",
		label: "This device",
		platform: "GhostWire Android",
		current: true,
		verified: true,
		lastSeenAgo: "now"
	},
	{
		id: "d-pixel",
		label: "Pixel 8",
		platform: "GrapheneOS",
		verified: true,
		lastSeenAgo: "2h ago"
	},
	{
		id: "d-tab",
		label: "Tablet",
		platform: "GhostWire Android",
		verified: true,
		lastSeenAgo: "yesterday"
	}
];
var META_KEY = "ghostwire-meta-v1";
var VAULT_KEY = "ghostwire-vault-v1";
var livePipes = /* @__PURE__ */ new Map();
function registerLivePipe(conversationId, send) {
	livePipes.set(conversationId, send);
	return () => {
		livePipes.delete(conversationId);
	};
}
function readMeta() {
	if (typeof localStorage === "undefined") return null;
	try {
		const raw = localStorage.getItem(META_KEY);
		return raw ? JSON.parse(raw) : null;
	} catch {
		return null;
	}
}
function writeMeta(meta) {
	localStorage.setItem(META_KEY, JSON.stringify(meta));
}
function snapshotOf(state) {
	return {
		identity: state.identity,
		conversations: state.conversations,
		messages: state.messages,
		settings: state.settings
	};
}
async function persist(state, pin) {
	if (!state.identity) return;
	const snap = snapshotOf(state);
	const meta = readMeta();
	if (pin || meta?.hasPin) {
		const usedPin = pin;
		if (!usedPin) return;
		const blob = await wrapJson(usedPin, snap);
		localStorage.setItem(VAULT_KEY, blob);
		writeMeta({
			sealed: true,
			hasPin: true,
			salt: meta?.salt,
			pinHash: meta?.pinHash,
			duressHash: meta?.duressHash
		});
	} else {
		localStorage.setItem(VAULT_KEY, JSON.stringify(snap));
		writeMeta({
			sealed: false,
			hasPin: false
		});
	}
}
var persistPin = null;
var useVault = create((set, get) => ({
	phase: "boot",
	identity: null,
	conversations: [],
	messages: {},
	settings: defaultSettings(),
	activeId: null,
	rail: "inbox",
	query: "",
	infoOpen: false,
	call: null,
	busy: false,
	error: null,
	hasPin: false,
	boot: () => {
		const meta = readMeta();
		if (!meta) {
			set({
				phase: "onboarding",
				hasPin: false
			});
			return;
		}
		if (meta.sealed) {
			set({
				phase: "locked",
				hasPin: true
			});
			return;
		}
		try {
			const raw = localStorage.getItem(VAULT_KEY);
			if (!raw) {
				set({ phase: "onboarding" });
				return;
			}
			const snap = JSON.parse(raw);
			set({
				phase: "ready",
				identity: snap.identity,
				conversations: snap.conversations,
				messages: snap.messages,
				settings: {
					...defaultSettings(),
					...snap.settings
				},
				activeId: snap.conversations.find((c) => !c.archived)?.id ?? null,
				hasPin: false
			});
		} catch {
			set({ phase: "onboarding" });
		}
	},
	completeOnboarding: async (callsign, pin, duress) => {
		set({
			busy: true,
			error: null
		});
		try {
			const keys = await generateIdentity();
			const identity = {
				id: keys.id,
				callsign: callsign.trim() || "Operator",
				fingerprint: keys.fingerprint,
				createdAt: Date.now()
			};
			const seeded = buildSeed(identity);
			let meta = {
				sealed: false,
				hasPin: false
			};
			if (pin) {
				const hashed = await pinHash(pin);
				let duressHash;
				if (duress) duressHash = (await pinHash(duress, hashed.salt)).hash;
				meta = {
					sealed: true,
					hasPin: true,
					salt: hashed.salt,
					pinHash: hashed.hash,
					duressHash
				};
				persistPin = pin;
			}
			writeMeta(meta);
			set({
				phase: "ready",
				identity,
				conversations: seeded.conversations,
				messages: seeded.messages,
				settings: defaultSettings(),
				activeId: "c-ops",
				hasPin: Boolean(pin),
				busy: false
			});
			await persist(get(), pin);
		} catch (err) {
			set({
				busy: false,
				error: err instanceof Error ? err.message : "Vault setup failed"
			});
		}
	},
	unlock: async (pin) => {
		const meta = readMeta();
		if (!meta?.salt || !meta.pinHash) return "bad";
		const hashed = await pinHash(pin, meta.salt);
		if (meta.duressHash && hashed.hash === meta.duressHash) {
			get().wipe();
			return "duress";
		}
		if (hashed.hash !== meta.pinHash) return "bad";
		try {
			const raw = localStorage.getItem(VAULT_KEY);
			if (!raw) return "bad";
			const snap = await unwrapJson(pin, raw);
			persistPin = pin;
			set({
				phase: "ready",
				identity: snap.identity,
				conversations: snap.conversations,
				messages: snap.messages,
				settings: {
					...defaultSettings(),
					...snap.settings
				},
				activeId: snap.conversations.find((c) => !c.archived)?.id ?? null,
				hasPin: true,
				error: null
			});
			return "ok";
		} catch {
			return "bad";
		}
	},
	lock: async () => {
		const state = get();
		if (state.hasPin && persistPin) await persist(state, persistPin);
		else await persist(state);
		persistPin = null;
		set({
			phase: state.hasPin ? "locked" : "ready",
			identity: state.hasPin ? null : state.identity,
			conversations: state.hasPin ? [] : state.conversations,
			messages: state.hasPin ? {} : state.messages,
			call: null
		});
	},
	wipe: () => {
		persistPin = null;
		localStorage.removeItem(VAULT_KEY);
		localStorage.removeItem(META_KEY);
		set({
			phase: "onboarding",
			identity: null,
			conversations: [],
			messages: {},
			settings: defaultSettings(),
			activeId: null,
			call: null,
			hasPin: false,
			error: null
		});
	},
	setRail: (rail) => set({
		rail,
		activeId: rail === "vault" ? get().activeId : get().activeId
	}),
	setActive: (id) => {
		if (!id) {
			set({
				activeId: null,
				infoOpen: false
			});
			return;
		}
		set((s) => ({
			activeId: id,
			conversations: s.conversations.map((c) => c.id === id ? {
				...c,
				unread: 0,
				knocked: false
			} : c)
		}));
	},
	setQuery: (query) => set({ query }),
	setInfoOpen: (infoOpen) => set({ infoOpen }),
	sendMessage: async (conversationId, draft) => {
		const state = get();
		const identity = state.identity;
		if (!identity || !draft.body.trim() && draft.kind !== "knock" && !draft.fileName) return;
		const conv = state.conversations.find((c) => c.id === conversationId);
		const ttl = draft.ttlHours ?? conv?.ttlHours ?? state.settings.defaultTtl;
		const kind = draft.kind ?? (draft.fileName ? "file" : "text");
		const now = Date.now();
		const message = {
			id: randomId("m"),
			conversationId,
			kind,
			fromId: identity.id,
			fromName: identity.callsign,
			body: kind === "dead-drop" ? "" : draft.body.trim(),
			at: now,
			ttlHours: ttl,
			expiresAt: ttl ? now + ttl * 60 * 60 * 1e3 : void 0,
			sealed: kind === "dead-drop",
			consumed: kind === "dead-drop",
			replyTo: draft.replyTo,
			fileName: draft.fileName,
			delivered: true,
			mine: true
		};
		const preview = kind === "dead-drop" ? "Dead drop sent · no copy retained" : kind === "knock" ? "Knock" : draft.body.trim() || draft.fileName || "";
		set((s) => ({
			messages: {
				...s.messages,
				[conversationId]: [...s.messages[conversationId] ?? [], message]
			},
			conversations: s.conversations.map((c) => c.id === conversationId ? {
				...c,
				lastAt: now,
				lastPreview: preview,
				unread: 0
			} : c)
		}));
		const pipe = livePipes.get(conversationId);
		if (pipe) pipe({
			type: "msg",
			message: {
				...message,
				body: draft.body.trim(),
				mine: false,
				fromId: identity.id,
				fromName: identity.callsign
			}
		});
		persist(get(), persistPin ?? void 0);
	},
	ingestRemote: (conversationId, message) => {
		set((s) => {
			if ((s.messages[conversationId] ?? []).some((m) => m.id === message.id)) return s;
			const conv = s.conversations.find((c) => c.id === conversationId);
			const unreadBump = s.activeId === conversationId ? 0 : 1;
			return {
				messages: {
					...s.messages,
					[conversationId]: [...s.messages[conversationId] ?? [], {
						...message,
						mine: false
					}]
				},
				conversations: s.conversations.map((c) => c.id === conversationId ? {
					...c,
					lastAt: message.at,
					lastPreview: message.kind === "dead-drop" ? "Sealed packet" : message.kind === "knock" ? "Knock" : message.body,
					unread: c.unread + unreadBump,
					knocked: message.kind === "knock" ? true : c.knocked
				} : c),
				activeId: conv ? s.activeId : s.activeId
			};
		});
		persist(get(), persistPin ?? void 0);
	},
	openDeadDrop: (conversationId, messageId) => {
		set((s) => ({ messages: {
			...s.messages,
			[conversationId]: (s.messages[conversationId] ?? []).map((m) => m.id === messageId ? {
				...m,
				sealed: false,
				consumed: true
			} : m)
		} }));
		window.setTimeout(() => {
			set((s) => ({ messages: {
				...s.messages,
				[conversationId]: (s.messages[conversationId] ?? []).map((m) => m.id === messageId ? {
					...m,
					body: "",
					sealed: false,
					consumed: true
				} : m)
			} }));
			persist(get(), persistPin ?? void 0);
		}, 2e4);
	},
	react: (conversationId, messageId, reaction) => {
		set((s) => ({ messages: {
			...s.messages,
			[conversationId]: (s.messages[conversationId] ?? []).map((m) => m.id === messageId ? {
				...m,
				reaction: m.reaction === reaction ? null : reaction
			} : m)
		} }));
		persist(get(), persistPin ?? void 0);
	},
	knock: (conversationId) => {
		get().sendMessage(conversationId, {
			body: "Knock",
			kind: "knock"
		});
		set((s) => ({ conversations: s.conversations.map((c) => c.id === conversationId ? {
			...c,
			knocked: true
		} : c) }));
		window.setTimeout(() => {
			set((s) => ({ conversations: s.conversations.map((c) => c.id === conversationId ? {
				...c,
				knocked: false
			} : c) }));
		}, 900);
	},
	verifyContact: (conversationId) => {
		set((s) => ({ conversations: s.conversations.map((c) => c.id === conversationId ? {
			...c,
			verified: true,
			subtitle: c.kind === "direct" ? "Verified · sealed" : c.subtitle,
			members: c.members.map((m) => ({
				...m,
				verified: true
			}))
		} : c) }));
		if (get().identity) {
			const now = Date.now();
			const system = {
				id: randomId("m"),
				conversationId,
				kind: "system",
				fromId: "system",
				fromName: "Vault",
				body: "Fingerprints matched · session sealed",
				at: now,
				ttlHours: 0,
				delivered: true
			};
			set((s) => ({ messages: {
				...s.messages,
				[conversationId]: [...s.messages[conversationId] ?? [], system]
			} }));
		}
		persist(get(), persistPin ?? void 0);
	},
	setTtl: (conversationId, ttlHours) => {
		set((s) => ({ conversations: s.conversations.map((c) => c.id === conversationId ? {
			...c,
			ttlHours
		} : c) }));
		persist(get(), persistPin ?? void 0);
	},
	toggleMute: (conversationId) => {
		set((s) => ({ conversations: s.conversations.map((c) => c.id === conversationId ? {
			...c,
			muted: !c.muted
		} : c) }));
		persist(get(), persistPin ?? void 0);
	},
	archive: (conversationId, archived = true) => {
		set((s) => ({
			conversations: s.conversations.map((c) => c.id === conversationId ? {
				...c,
				archived
			} : c),
			activeId: s.activeId === conversationId ? null : s.activeId
		}));
		persist(get(), persistPin ?? void 0);
	},
	updateSettings: (patch) => {
		set((s) => ({ settings: {
			...s.settings,
			...patch
		} }));
		persist(get(), persistPin ?? void 0);
	},
	setPin: async (pin, duress) => {
		const hashed = await pinHash(pin);
		let duressHash;
		if (duress) duressHash = (await pinHash(duress, hashed.salt)).hash;
		writeMeta({
			sealed: true,
			hasPin: true,
			salt: hashed.salt,
			pinHash: hashed.hash,
			duressHash
		});
		persistPin = pin;
		set({ hasPin: true });
		await persist(get(), pin);
	},
	createLive: () => {
		const identity = get().identity;
		const code = generateInviteCode();
		const conv = {
			id: `c-live-${roomIdFromCode(code)}`,
			kind: "live",
			title: "Sealed channel",
			subtitle: displayCode(code),
			hue: 4,
			verified: true,
			muted: false,
			archived: false,
			pinned: false,
			unread: 0,
			ttlHours: get().settings.defaultTtl,
			lastAt: Date.now(),
			lastPreview: "Waiting for peer",
			roomCode: displayCode(code),
			livePeers: 0,
			members: identity ? [{
				id: identity.id,
				name: identity.callsign,
				fingerprint: identity.fingerprint,
				verified: true,
				hue: 0
			}] : []
		};
		const system = {
			id: randomId("m"),
			conversationId: conv.id,
			kind: "system",
			fromId: "system",
			fromName: "Vault",
			body: `Invite ${displayCode(code)} · hybrid PQ ratchet · ciphertext never stored in plaintext`,
			at: Date.now(),
			ttlHours: 0,
			delivered: true
		};
		set((s) => ({
			conversations: [conv, ...s.conversations],
			messages: {
				...s.messages,
				[conv.id]: [system]
			},
			activeId: conv.id,
			rail: "live"
		}));
		persist(get(), persistPin ?? void 0);
		return conv;
	},
	joinLive: (code) => {
		const room = roomIdFromCode(code);
		if (room.length < 6) return null;
		const existing = get().conversations.find((c) => c.id === `c-live-${room}`);
		if (existing) {
			set({
				activeId: existing.id,
				rail: "live"
			});
			return existing;
		}
		const identity = get().identity;
		const conv = {
			id: `c-live-${room}`,
			kind: "live",
			title: "Sealed channel",
			subtitle: displayCode(code),
			hue: 4,
			verified: true,
			muted: false,
			archived: false,
			pinned: false,
			unread: 0,
			ttlHours: get().settings.defaultTtl,
			lastAt: Date.now(),
			lastPreview: "Joining…",
			roomCode: displayCode(code),
			livePeers: 0,
			members: identity ? [{
				id: identity.id,
				name: identity.callsign,
				fingerprint: identity.fingerprint,
				verified: true,
				hue: 0
			}] : []
		};
		const system = {
			id: randomId("m"),
			conversationId: conv.id,
			kind: "system",
			fromId: "system",
			fromName: "Vault",
			body: `Joined ${displayCode(code)} · waiting for peer handshake`,
			at: Date.now(),
			ttlHours: 0,
			delivered: true
		};
		set((s) => ({
			conversations: [conv, ...s.conversations],
			messages: {
				...s.messages,
				[conv.id]: [system]
			},
			activeId: conv.id,
			rail: "live"
		}));
		persist(get(), persistPin ?? void 0);
		return conv;
	},
	setLivePeers: (conversationId, count) => {
		set((s) => ({ conversations: s.conversations.map((c) => c.id === conversationId ? {
			...c,
			livePeers: count,
			lastPreview: count > 0 ? `${count} peer${count === 1 ? "" : "s"} on channel` : "Waiting for peer"
		} : c) }));
	},
	startCall: (conversationId, mode) => {
		set({ call: {
			conversationId,
			mode,
			status: "ringing",
			startedAt: Date.now()
		} });
		window.setTimeout(() => {
			const call = get().call;
			if (call && call.status === "ringing") set({ call: {
				...call,
				status: "active",
				startedAt: Date.now()
			} });
		}, 1400);
	},
	endCall: () => set({ call: null }),
	purgeExpired: () => {
		const now = Date.now();
		set((s) => {
			let changed = false;
			const next = {};
			for (const [id, list] of Object.entries(s.messages)) {
				const kept = list.filter((m) => !m.expiresAt || m.expiresAt > now);
				if (kept.length !== list.length) changed = true;
				next[id] = kept;
			}
			return changed ? { messages: next } : s;
		});
	},
	rename: (callsign) => {
		const name = callsign.trim();
		if (!name) return;
		set((s) => s.identity ? {
			identity: {
				...s.identity,
				callsign: name
			},
			conversations: s.conversations.map((c) => ({
				...c,
				members: c.members.map((m) => m.id === s.identity?.id ? {
					...m,
					name
				} : m)
			}))
		} : s);
		persist(get(), persistPin ?? void 0);
	}
}));
function StatusBar() {
	const shield = useVault((s) => s.settings.screenshotShield);
	const time = (/* @__PURE__ */ new Date()).toLocaleTimeString(void 0, {
		hour: "2-digit",
		minute: "2-digit"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-7 shrink-0 items-center justify-between bg-bg px-3 text-[11px] tabular-nums text-muted",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: time }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center gap-1.5 font-medium tracking-[0.14em] text-subtle uppercase",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostMark, { className: "size-3" }), "GhostWire"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center gap-2",
				children: [
					shield ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3 text-ice" }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wifi, { className: "size-3" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Battery, { className: "size-3.5" })
				]
			})
		]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,color] duration-150 ease-out disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:opacity-90",
			ghost: "text-fg hover:bg-elevated",
			outline: "border border-border bg-transparent text-fg hover:bg-elevated",
			danger: "bg-danger/15 text-danger hover:bg-danger/25",
			ice: "bg-ice/15 text-ice hover:bg-ice/25"
		},
		size: {
			sm: "h-8 px-3 text-xs",
			md: "h-10 px-4",
			lg: "h-11 px-5",
			icon: "size-10",
			"icon-sm": "size-8"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var Dialog = Dialog$1;
function DialogContent({ className, children, title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-bg/70 data-[state=open]:animate-in data-[state=closed]:animate-out" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed left-1/2 top-1/2 z-50 w-[min(440px,calc(100vw-24px))] -translate-x-1/2 -translate-y-1/2", "rounded-xl border border-border bg-surface p-5 shadow-[var(--shadow-border)]", "duration-250 data-[state=open]:animate-in data-[state=closed]:animate-out", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "text-base font-medium tracking-tight",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
				className: "flex size-8 items-center justify-center rounded-md text-muted hover:bg-elevated hover:text-fg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
			})]
		}), children]
	})] });
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-10 w-full rounded-md border border-border bg-elevated px-3 text-sm text-fg placeholder:text-subtle", "transition-[border-color,box-shadow] duration-150", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ice/60", className),
		...props
	});
}
function Switch({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		className: cn("peer inline-flex h-6 w-10 shrink-0 items-center rounded-full border border-border bg-elevated transition-colors", "data-[state=checked]:bg-accent data-[state=checked]:border-accent", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: cn("block size-4 rounded-full bg-muted transition-transform duration-150 translate-x-1", "data-[state=checked]:translate-x-5 data-[state=checked]:bg-accent-fg") })
	});
}
function Onboarding() {
	const completeOnboarding = useVault((s) => s.completeOnboarding);
	const busy = useVault((s) => s.busy);
	const error = useVault((s) => s.error);
	const [callsign, setCallsign] = (0, import_react.useState)("Operator");
	const [pin, setPin] = (0, import_react.useState)("");
	const [duress, setDuress] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative flex min-h-dvh items-center justify-center px-5 py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(158,179,199,0.08),transparent_55%)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "stagger-in relative w-full max-w-md rounded-xl border border-border bg-surface p-6 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostMark, { className: "size-10" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 font-mono text-[11px] tracking-[0.22em] text-ice uppercase",
					children: "GhostWire for Android"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 text-3xl font-medium tracking-tight text-fg",
					children: "Independent messenger. Own backend. No Wire servers."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted",
					children: [
						"A standalone Android client in the Wire protocol lineage — not affiliated with Wire Swiss GmbH. Zero identity, invite pairing, hybrid post-quantum ratchet. Package",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-fg",
							children: "app.ghostwire"
						}),
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "mt-6 block text-xs font-medium text-muted",
					children: "Callsign"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-1.5",
					value: callsign,
					onChange: (e) => setCallsign(e.target.value),
					maxLength: 24,
					autoComplete: "off"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "mt-4 block text-xs font-medium text-muted",
					children: "Vault PIN — optional"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-1.5",
					type: "password",
					inputMode: "numeric",
					value: pin,
					onChange: (e) => setPin(e.target.value),
					placeholder: "Locks the vault on this device",
					autoComplete: "new-password"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "mt-4 block text-xs font-medium text-muted",
					children: "Duress PIN — optional"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-1.5",
					type: "password",
					inputMode: "numeric",
					value: duress,
					onChange: (e) => setDuress(e.target.value),
					placeholder: "Wipes keys and messages",
					autoComplete: "new-password"
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-6 w-full",
					disabled: busy || callsign.trim().length < 2,
					onClick: () => void completeOnboarding(callsign, pin || void 0, duress || void 0),
					children: "Create local vault"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs leading-relaxed text-subtle",
					children: "Does not connect to wire.com. Built for GrapheneOS / Android 14+ without Google Play Services."
				})
			]
		})]
	});
}
function LockScreen() {
	const unlock = useVault((s) => s.unlock);
	const [pin, setPin] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("idle");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function submit() {
		setBusy(true);
		const result = await unlock(pin);
		setBusy(false);
		if (result === "ok") return;
		if (result === "duress") {
			setStatus("duress");
			toast("Vault destroyed");
			return;
		}
		setStatus("bad");
		setPin("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-dvh items-center justify-center px-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "w-full max-w-sm rounded-xl border border-border bg-surface p-7 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mx-auto flex size-12 items-center justify-center rounded-full bg-elevated",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-5 text-ice" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 text-xl font-medium tracking-tight",
					children: "Vault locked"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Enter the vault PIN. The duress PIN wipes this device."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-5 text-center tracking-[0.4em]",
					type: "password",
					inputMode: "numeric",
					value: pin,
					autoFocus: true,
					onChange: (e) => setPin(e.target.value),
					onKeyDown: (e) => {
						if (e.key === "Enter") submit();
					}
				}),
				status === "bad" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-danger",
					children: "PIN rejected"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-5 w-full",
					disabled: busy || pin.length < 4,
					onClick: () => void submit(),
					children: "Unlock"
				})
			]
		})
	});
}
function CallOverlay() {
	const call = useVault((s) => s.call);
	const conversations = useVault((s) => s.conversations);
	const endCall = useVault((s) => s.endCall);
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [camOff, setCamOff] = (0, import_react.useState)(false);
	const [now, setNow] = (0, import_react.useState)(Date.now());
	(0, import_react.useEffect)(() => {
		if (!call) return;
		const id = window.setInterval(() => setNow(Date.now()), 500);
		return () => window.clearInterval(id);
	}, [call]);
	if (!call) return null;
	const conv = conversations.find((c) => c.id === call.conversationId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex flex-col items-center justify-center bg-bg/95 px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonMark, {
				name: conv?.title ?? "Channel",
				hue: conv?.hue ?? 0,
				size: "lg"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-lg font-medium",
				children: conv?.title ?? "Channel"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-mono text-sm tabular-nums text-muted",
				children: call.status === "ringing" ? "Sealing session…" : formatDuration(now - call.startedAt)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs text-subtle",
				children: [call.mode === "video" ? "Video" : "Voice", " · ML-KEM frame keys · DTLS-SRTP"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "icon",
						"aria-label": muted ? "Unmute" : "Mute",
						onClick: () => setMuted((v) => !v),
						children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicOff, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, {})
					}),
					call.mode === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "icon",
						"aria-label": camOff ? "Camera on" : "Camera off",
						onClick: () => setCamOff((v) => !v),
						children: camOff ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoOff, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, {})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "danger",
						size: "lg",
						onClick: endCall,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneOff, { className: "size-4" }), "End"]
					})
				]
			})
		]
	});
}
function InviteDialog({ open, onOpenChange }) {
	const createLive = useVault((s) => s.createLive);
	const joinLive = useVault((s) => s.joinLive);
	const [mode, setMode] = (0, import_react.useState)("create");
	const [code, setCode] = (0, import_react.useState)("");
	const [created, setCreated] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!open) {
			setCreated(null);
			setCode("");
			setMode("create");
		}
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			title: "Sealed channel",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 flex rounded-md bg-elevated p-1",
				children: ["create", "join"].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: `h-8 flex-1 rounded-sm text-sm capitalize ${mode === id ? "bg-surface text-fg" : "text-muted"}`,
					onClick: () => setMode(id),
					children: id
				}, id))
			}), mode === "create" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Pair another GhostWire Android client. The invite is the secret — traffic never touches Wire Swiss infrastructure."
			}), created ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-lg bg-elevated p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-lg tracking-[0.18em] text-fg",
					children: created
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					className: "mt-3",
					onClick: () => {
						navigator.clipboard.writeText(created);
						toast("Invite copied");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), "Copy invite"]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-5 w-full",
				onClick: () => {
					const conv = createLive();
					setCreated(conv.roomCode ?? "");
				},
				children: "Generate invite"
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: code,
				onChange: (e) => setCode(e.target.value.toUpperCase()),
				placeholder: "GW-XXXX-XXXX",
				className: "font-mono tracking-wide"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4 w-full",
				disabled: code.replace(/[^a-zA-Z0-9]/g, "").length < 6,
				onClick: () => {
					if (!joinLive(code)) {
						toast("Invite rejected");
						return;
					}
					onOpenChange(false);
				},
				children: "Join channel"
			})] })]
		})
	});
}
var forkRows = [
	[
		"Identity",
		"Email / phone account",
		"Zero identity, local vault"
	],
	[
		"Backend",
		"Wire Swiss cloud",
		"Own P2P + local store"
	],
	[
		"Ratchet",
		"Proteus / MLS",
		"MLS + hybrid ML-KEM-768"
	],
	[
		"Ephemeral",
		"Timer messages",
		"Dead drops, no sender copy"
	],
	[
		"Lock",
		"App lock PIN",
		"Vault PIN + duress wipe"
	],
	[
		"Screenshots",
		"Optional FLAG_SECURE",
		"Shield on by default"
	],
	[
		"Presence",
		"Last seen",
		"Stealth, no last-seen"
	],
	[
		"Push",
		"FCM / HMS",
		"No Google Play Services"
	]
];
function VaultPanel() {
	const identity = useVault((s) => s.identity);
	const settings = useVault((s) => s.settings);
	const updateSettings = useVault((s) => s.updateSettings);
	const setPin = useVault((s) => s.setPin);
	const wipe = useVault((s) => s.wipe);
	const rename = useVault((s) => s.rename);
	const lock = useVault((s) => s.lock);
	const hasPin = useVault((s) => s.hasPin);
	const [callsign, setCallsign] = (0, import_react.useState)(identity?.callsign ?? "");
	const [pin, setPinValue] = (0, import_react.useState)("");
	const [duress, setDuress] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => setCallsign(identity?.callsign ?? ""), [identity?.callsign]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-lg space-y-6 px-5 py-6 pb-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-[11px] tracking-[0.2em] text-ice uppercase",
				children: "app.ghostwire"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-2xl font-medium tracking-tight",
				children: "Android vault"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg border border-border bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonMark, {
								name: identity?.callsign ?? "GW",
								hue: 0,
								verified: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-medium",
									children: identity?.callsign
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-[11px] text-muted",
									children: identity?.fingerprint
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon-sm",
								className: "ml-auto",
								"aria-label": "Copy fingerprint",
								onClick: () => {
									if (identity?.fingerprint) {
										navigator.clipboard.writeText(identity.fingerprint);
										toast("Fingerprint copied");
									}
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-4 block text-xs text-muted",
						children: "Callsign"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1.5 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: callsign,
							onChange: (e) => setCallsign(e.target.value),
							maxLength: 24
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => rename(callsign),
							children: "Save"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg border border-border bg-surface p-4 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Hardening"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Screenshot shield",
						hint: "FLAG_SECURE analogue — blocks capture",
						checked: settings.screenshotShield,
						onChange: (v) => updateSettings({ screenshotShield: v })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Stealth",
						hint: "Hide last-seen and typing",
						checked: settings.stealth,
						onChange: (v) => updateSettings({ stealth: v })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Cover traffic",
						hint: "Pad live channels with dummy frames",
						checked: settings.coverTraffic,
						onChange: (v) => updateSettings({ coverTraffic: v })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Read receipts",
						hint: "Off by default",
						checked: settings.readReceipts,
						onChange: (v) => updateSettings({ readReceipts: v })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: "Default timer"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex gap-1",
						children: [
							0,
							1,
							24,
							72
						].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => updateSettings({ defaultTtl: h }),
							className: `h-8 rounded-full px-3 text-xs ${settings.defaultTtl === h ? "bg-accent text-accent-fg" : "bg-elevated text-muted"}`,
							children: ttlLabel(h)
						}, h))
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg border border-border bg-surface p-4 space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "flex items-center gap-2 text-sm font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fingerprint, { className: "size-4 text-ice" }), "PIN"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "password",
						inputMode: "numeric",
						placeholder: hasPin ? "Replace vault PIN" : "Set vault PIN",
						value: pin,
						onChange: (e) => setPinValue(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "password",
						inputMode: "numeric",
						placeholder: "Duress PIN (wipe)",
						value: duress,
						onChange: (e) => setDuress(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							disabled: pin.length < 4,
							onClick: () => {
								setPin(pin, duress || void 0);
								setPinValue("");
								setDuress("");
								toast("Vault PIN stored locally");
							},
							children: "Save PINs"
						}), hasPin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							onClick: () => void lock(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4" }), "Lock now"]
						}) : null]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg border border-border bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "flex items-center gap-2 text-sm font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-4 text-ice" }), "Independent fork"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: "GhostWire is an independent Android client inspired by the open-source Wire protocol (Proteus / MLS / AVS). It is not a product of Wire Swiss GmbH, does not use Wire trademarks, and does not connect to Wire servers."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-left text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-subtle",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pb-2 font-medium",
										children: " "
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pb-2 font-medium",
										children: "Wire Android"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pb-2 font-medium",
										children: "GhostWire"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
								className: "text-fg",
								children: forkRows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t border-border",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 pr-2 text-muted",
											children: row[0]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 pr-2",
											children: row[1]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 text-ice",
											children: row[2]
										})
									]
								}, row[0]))
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-mono text-[11px] text-subtle",
						children: "v2.0.0 · app.ghostwire · GrapheneOS ready"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						className: "mt-4",
						onClick: () => {
							if (window.confirm("Destroy this vault? Keys and messages cannot be recovered.")) wipe();
						},
						children: "Destroy vault"
					})
				]
			})
		]
	});
}
function Row({ label, hint, checked, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex items-center justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-sm",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-xs text-subtle",
			children: hint
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
			checked,
			onCheckedChange: onChange
		})]
	});
}
function Badge({ className, tone = "muted", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center gap-1 rounded-sm px-1.5 py-0.5 text-[11px] font-medium tracking-wide", {
			muted: "bg-elevated text-muted",
			ice: "bg-ice/15 text-ice",
			verified: "bg-verified/15 text-verified",
			warn: "bg-warn/15 text-warn",
			danger: "bg-danger/15 text-danger"
		}[tone], className),
		...props
	});
}
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
function DropdownMenuContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		sideOffset: 6,
		className: cn("z-50 min-w-44 rounded-lg border border-border bg-surface p-1 shadow-[var(--shadow-border)]", className),
		...props
	}) });
}
function DropdownMenuItem({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
		className: cn("flex cursor-pointer items-center gap-2 rounded-md px-2.5 py-2 text-sm text-fg outline-none", "data-[highlighted]:bg-elevated", className),
		...props
	});
}
function ChatPane({ onBack }) {
	const conversations = useVault((s) => s.conversations);
	const messages = useVault((s) => s.messages);
	const activeId = useVault((s) => s.activeId);
	const infoOpen = useVault((s) => s.infoOpen);
	const setInfoOpen = useVault((s) => s.setInfoOpen);
	const conv = conversations.find((c) => c.id === activeId) ?? null;
	const list = conv ? messages[conv.id] ?? [] : [];
	if (!conv) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col items-center justify-center bg-bg px-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-8 text-subtle" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-lg font-medium",
				children: "Select a conversation"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-sm text-sm text-muted",
				children: "Independent Android client. Inbox is local. Open a sealed channel to pair another GhostWire device — no Wire servers."
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex min-w-0 flex-1 flex-col bg-bg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatHeader, {
					conversation: conv,
					onBack,
					onInfo: () => setInfoOpen(!infoOpen)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageList, {
					conversation: conv,
					messages: list
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Composer, { conversation: conv })
			]
		}), infoOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoPanel, {
			conversation: conv,
			onClose: () => setInfoOpen(false)
		}) : null]
	});
}
function ChatHeader({ conversation, onBack, onInfo }) {
	const startCall = useVault((s) => s.startCall);
	const knock = useVault((s) => s.knock);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex items-center gap-2 border-b border-border bg-surface px-2 py-2 sm:px-4",
		children: [
			onBack ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "flex size-10 items-center justify-center rounded-md text-muted hover:bg-elevated hover:text-fg md:hidden",
				onClick: onBack,
				"aria-label": "Back",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonMark, {
				name: conversation.title,
				hue: conversation.hue,
				verified: conversation.verified
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-sm font-medium",
					children: conversation.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-[11px] text-muted",
					children: conversation.kind === "live" ? `${conversation.livePeers ?? 0} peer · ${conversation.roomCode}` : conversation.verified ? "PQ · MLS · sealed" : "Unverified fingerprint"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
						label: "Voice",
						onClick: () => startCall(conversation.id, "audio"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
						label: "Video",
						onClick: () => startCall(conversation.id, "video"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
						label: "Knock",
						onClick: () => knock(conversation.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
						label: "Details",
						onClick: onInfo,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-4" })
					})
				]
			})
		]
	});
}
function IconBtn({ label, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		"aria-label": label,
		onClick,
		className: "flex size-10 items-center justify-center rounded-md text-muted hover:bg-elevated hover:text-fg",
		children
	});
}
function MessageList({ conversation, messages }) {
	const scroller = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		scroller.current?.scrollTo({ top: scroller.current.scrollHeight });
	}, [messages.length, conversation.id]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: scroller,
		className: "min-h-0 flex-1 overflow-y-auto px-3 py-4 sm:px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto flex max-w-2xl flex-col gap-3",
			children: messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageBubble, {
				message: m,
				conversation
			}, m.id))
		})
	});
}
function MessageBubble({ message, conversation }) {
	const react = useVault((s) => s.react);
	const openDeadDrop = useVault((s) => s.openDeadDrop);
	const hue = conversation.members.find((m) => m.id === message.fromId)?.hue ?? conversation.hue;
	if (message.kind === "system") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-1 text-center font-mono text-[11px] tracking-wide text-subtle",
		children: message.body
	});
	if (message.kind === "knock") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "py-1 text-center text-xs text-ice",
		children: [message.fromName, " knocked on this channel"]
	});
	const sealedDrop = message.kind === "dead-drop" && message.sealed && !message.mine;
	const emptyDrop = message.kind === "dead-drop" && (message.mine || message.consumed) && !message.body;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("flex gap-2", message.mine ? "flex-row-reverse" : "flex-row"),
		children: [!message.mine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonMark, {
			name: message.fromName,
			hue,
			size: "sm"
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("max-w-[min(100%,28rem)]", message.mine && "items-end"),
			children: [
				!message.mine && conversation.kind === "group" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 px-1 text-[11px] text-muted",
					children: message.fromName
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("rounded-lg px-3 py-2 text-sm leading-relaxed", message.mine ? "bg-self text-fg" : "bg-elevated text-fg", message.kind === "dead-drop" && "border border-dashed border-ice/40"),
					children: [
						message.replyTo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-1.5 border-l-2 border-ice/50 pl-2 text-xs text-muted",
							children: [
								message.replyTo.fromName,
								": ",
								message.replyTo.body
							]
						}) : null,
						sealedDrop ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "flex items-center gap-2 text-ice",
							onClick: () => openDeadDrop(conversation.id, message.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-4" }), "Break seal — one-shot"]
						}) : emptyDrop ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: [
								"Dead drop ",
								message.mine ? "sent" : "consumed",
								" · no copy retained"
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "whitespace-pre-wrap",
							children: message.body
						}),
						message.fileName ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-ice",
							children: message.fileName
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("mt-1 flex items-center gap-2 px-1", message.mine && "justify-end"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-[10px] tabular-nums text-subtle",
							children: formatTime(message.at)
						}),
						message.ttlHours ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-0.5 text-[10px] text-subtle",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "size-2.5" }), ttlLabel(message.ttlHours)]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: cn("text-subtle hover:text-fg", message.reaction === "ack" && "text-verified"),
							"aria-label": "Acknowledge",
							onClick: () => react(conversation.id, message.id, "ack"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: cn("text-subtle hover:text-fg", message.reaction === "flag" && "text-warn"),
							"aria-label": "Flag",
							onClick: () => react(conversation.id, message.id, "flag"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, { className: "size-3" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: cn("text-subtle hover:text-fg", message.reaction === "hold" && "text-ice"),
							"aria-label": "Hold",
							onClick: () => react(conversation.id, message.id, "hold"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3" })
						})
					]
				})
			]
		})]
	});
}
function Composer({ conversation }) {
	const sendMessage = useVault((s) => s.sendMessage);
	const setTtl = useVault((s) => s.setTtl);
	const [text, setText] = (0, import_react.useState)("");
	const [drop, setDrop] = (0, import_react.useState)(conversation.kind === "dead-drop");
	const [fileName, setFileName] = (0, import_react.useState)();
	const area = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setDrop(conversation.kind === "dead-drop");
		setText("");
		setFileName(void 0);
	}, [conversation.id, conversation.kind]);
	function submit() {
		const body = text.trim();
		if (!body && !fileName) return;
		sendMessage(conversation.id, {
			body,
			kind: drop ? "dead-drop" : fileName ? "file" : "text",
			ttlHours: conversation.ttlHours,
			fileName
		});
		setText("");
		setFileName(void 0);
		if (area.current) area.current.style.height = "auto";
	}
	function onKey(e) {
		if (e.key === "Enter" && !e.shiftKey) {
			e.preventDefault();
			submit();
		}
	}
	function onInput(e) {
		const el = e.currentTarget;
		el.style.height = "auto";
		el.style.height = `${Math.min(el.scrollHeight, 160)}px`;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "border-t border-border bg-surface px-3 py-3 sm:px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-2xl items-end gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex size-10 shrink-0 cursor-pointer items-center justify-center rounded-md text-muted hover:bg-elevated hover:text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						className: "sr-only",
						onChange: (e) => {
							const file = e.target.files?.[0];
							if (file) {
								if (file.size > 26214400) {
									toast("Max 25 MiB");
									return;
								}
								setFileName(file.name);
							}
						}
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1 rounded-lg bg-elevated px-3 py-1.5",
					children: [fileName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-1 flex items-center justify-between text-xs text-ice",
						children: [fileName, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-muted",
							onClick: () => setFileName(void 0),
							children: "Remove"
						})]
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						ref: area,
						rows: 1,
						value: text,
						onChange: (e) => setText(e.target.value),
						onKeyDown: onKey,
						onInput,
						placeholder: drop ? "Sealed one-shot…" : "Message",
						className: "max-h-40 w-full resize-none bg-transparent text-sm text-fg placeholder:text-subtle focus-visible:outline-none"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						"aria-label": "Timer",
						className: "flex size-10 shrink-0 items-center justify-center rounded-md text-muted hover:bg-elevated hover:text-fg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "size-4" })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuContent, { children: [
					0,
					1,
					24,
					72
				].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					onSelect: () => setTtl(conversation.id, h),
					children: [
						ttlLabel(h),
						" ",
						conversation.ttlHours === h ? "· current" : ""
					]
				}, h)) })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					"aria-label": "Dead drop",
					onClick: () => setDrop((v) => !v),
					className: cn("flex size-10 shrink-0 items-center justify-center rounded-md", drop ? "bg-ice/15 text-ice" : "text-muted hover:bg-elevated hover:text-fg"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "icon",
					"aria-label": "Send",
					disabled: !text.trim() && !fileName,
					onClick: submit,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
				})
			]
		})
	});
}
function InfoPanel({ conversation, onClose }) {
	const verifyContact = useVault((s) => s.verifyContact);
	const toggleMute = useVault((s) => s.toggleMute);
	const archive = useVault((s) => s.archive);
	const selfId = useVault((s) => s.identity?.id);
	const other = conversation.members.find((m) => m.id !== selfId) ?? conversation.members[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "flex h-full w-80 shrink-0 flex-col overflow-y-auto border-l border-border bg-surface max-lg:fixed max-lg:inset-y-0 max-lg:right-0 max-lg:z-40 max-lg:w-[min(100%,22rem)] max-lg:shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium",
					children: "Details"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					className: "text-sm text-muted hover:text-fg",
					children: "Close"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center px-4 pb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonMark, {
						name: conversation.title,
						hue: conversation.hue,
						size: "lg",
						verified: conversation.verified
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-medium",
						children: conversation.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: conversation.subtitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap justify-center gap-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: conversation.verified ? "verified" : "warn",
								children: conversation.verified ? "Verified" : "Unverified"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "ice",
								children: "PQ ratchet"
							}),
							conversation.kind === "group" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "MLS" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "1:1" }),
							conversation.kind === "live" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								tone: "ice",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-3" }), "Live"]
							}) : null
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 px-4 pb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] tracking-wide text-subtle uppercase",
							children: "Fingerprint"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-mono text-xs leading-relaxed text-fg",
							children: other?.fingerprint
						}),
						!conversation.verified ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ice",
							size: "sm",
							className: "mt-2",
							onClick: () => verifyContact(conversation.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldQuestion, { className: "size-3.5" }), "Mark verified"]
						}) : null
					] }),
					conversation.roomCode ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] tracking-wide text-subtle uppercase",
						children: "Invite"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "mt-1 font-mono text-sm text-ice",
						onClick: () => {
							navigator.clipboard.writeText(conversation.roomCode ?? "");
							toast("Invite copied");
						},
						children: conversation.roomCode
					})] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] tracking-wide text-subtle uppercase",
						children: "Members"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-2",
						children: conversation.members.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonMark, {
								name: m.name,
								hue: m.hue,
								size: "sm",
								verified: m.verified
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-sm",
									children: m.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-mono text-[10px] text-subtle",
									children: m.fingerprint
								})]
							})]
						}, m.id))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] tracking-wide text-subtle uppercase",
						children: "Devices"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-2",
						children: demoDevices.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [d.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 text-xs text-subtle",
								children: d.platform
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: d.lastSeenAgo
							})]
						}, d.id))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => toggleMute(conversation.id),
							children: conversation.muted ? "Unmute" : "Mute"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => archive(conversation.id, !conversation.archived),
							children: conversation.archived ? "Unarchive" : "Archive"
						})]
					})
				]
			})
		]
	});
}
var FAST_POLL_MS = 400;
var IDLE_POLL_MS = 2e3;
var PING_INTERVAL_MS = 2e3;
var STALL_MS = 1e4;
var MAX_RECOVERY_ATTEMPTS = 3;
var SIGNAL_RETRY_DELAYS_MS = [250, 750];
function defaultIceServers() {
	return [{ urls: ["stun:stun.l.google.com:19302", "stun:stun.cloudflare.com:3478"] }];
}
var P2PRoom = class {
	opts;
	peers = /* @__PURE__ */ new Map();
	/** Per-remote-peer signal delivery chains (order-preserving). */
	signalQueues = /* @__PURE__ */ new Map();
	cursor = 0;
	pollTimer = null;
	pingTimer = null;
	closed = false;
	everPolled = false;
	lastPeersFingerprint = "";
	constructor(opts) {
		this.opts = opts;
	}
	/**
	* The first poll IS the join: it registers this peer and returns the
	* roster. A failed first poll (cold DB, offline tab) must not strand the
	* room: the loop and timers start regardless and the next poll retries.
	*/
	async join() {
		try {
			await this.pollOnce();
		} catch {}
		if (this.closed) return;
		this.schedulePoll(this.anyPairConnecting() ? FAST_POLL_MS : IDLE_POLL_MS);
		this.pingTimer = setInterval(() => {
			this.pingAll();
			this.watchdog();
		}, PING_INTERVAL_MS);
	}
	close() {
		this.closed = true;
		if (this.pollTimer) clearTimeout(this.pollTimer);
		if (this.pingTimer) clearInterval(this.pingTimer);
		for (const slot of this.peers.values()) slot.pc.close();
		this.peers.clear();
		fetch("/api/rtc", {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				op: "leave",
				room: this.opts.room,
				peer: this.opts.selfId
			}),
			keepalive: true
		}).catch(() => {});
	}
	/** Send on the unreliable game-state channel (drops stale packets). */
	broadcast(data) {
		const wire = JSON.stringify({
			t: "d",
			d: data
		});
		for (const slot of this.peers.values()) if (slot.state?.readyState === "open") slot.state.send(wire);
	}
	/** Send reliably (ordered) to one peer, or to all when peerId is omitted. */
	send(data, peerId) {
		const wire = JSON.stringify({
			t: "d",
			d: data
		});
		const targets = peerId ? [this.peers.get(peerId)] : [...this.peers.values()];
		for (const slot of targets) if (slot?.reliable?.readyState === "open") slot.reliable.send(wire);
	}
	peerList() {
		return [...this.peers.values()].map((s) => ({ ...s.info }));
	}
	schedulePoll(delay) {
		if (this.closed) return;
		if (this.pollTimer) clearTimeout(this.pollTimer);
		this.pollTimer = setTimeout(() => void this.poll(), delay);
	}
	anyPairConnecting() {
		for (const s of this.peers.values()) {
			if (s.terminal) continue;
			if (s.info.connectionState !== "connected") return true;
		}
		return false;
	}
	async pollOnce() {
		const params = new URLSearchParams({
			room: this.opts.room,
			peer: this.opts.selfId,
			name: this.opts.name ?? "",
			since: String(this.cursor)
		});
		const res = await fetch(`/api/rtc?${params}`);
		if (this.closed) return;
		if (!res.ok) throw new Error(`signaling poll failed: ${res.status}`);
		const body = await res.json();
		if (this.closed) return;
		if (!this.everPolled) {
			this.everPolled = true;
			this.opts.onConnected?.();
		}
		this.reconcileRoster(body.peers);
		const roster = new Set(body.peers.map((p) => p.id));
		for (const sig of body.signals) {
			this.cursor = Math.max(this.cursor, sig.id);
			await this.onSignal(sig.from, sig.kind, sig.payload, roster);
			if (this.closed) return;
		}
	}
	async poll() {
		if (this.closed) return;
		try {
			await this.pollOnce();
		} catch {}
		this.schedulePoll(this.anyPairConnecting() ? FAST_POLL_MS : IDLE_POLL_MS);
	}
	reconcileRoster(peers) {
		const alive = new Set(peers.map((p) => p.id));
		for (const p of peers) {
			if (p.id === this.opts.selfId) continue;
			const existing = this.peers.get(p.id);
			if (existing) existing.info.name = p.name;
			else this.connectTo(p.id, p.name, this.opts.selfId > p.id);
		}
		for (const [id, slot] of this.peers) if (!alive.has(id)) {
			slot.pc.close();
			this.peers.delete(id);
		}
		this.emitPeers();
	}
	connectTo(peerId, name, initiator) {
		if (this.closed) return null;
		const pc = new RTCPeerConnection({ iceServers: this.opts.iceServers ?? defaultIceServers() });
		const slot = {
			pc,
			makingOffer: false,
			ignoreOffer: false,
			pendingCandidates: [],
			lastProgressAt: Date.now(),
			recoveryAttempts: 0,
			info: {
				id: peerId,
				name,
				connectionState: pc.connectionState,
				candidateType: null,
				rttMs: null
			}
		};
		this.peers.set(peerId, slot);
		pc.onicecandidate = (e) => {
			if (e.candidate) this.sendSignal(peerId, "ice", e.candidate.toJSON());
		};
		pc.onconnectionstatechange = () => {
			slot.info.connectionState = pc.connectionState;
			if (pc.connectionState === "connecting" || pc.connectionState === "connected") slot.lastProgressAt = Date.now();
			if (pc.connectionState === "connected") {
				slot.recoveryAttempts = 0;
				slot.terminal = false;
				this.readCandidateType(slot);
			}
			this.emitPeers();
			if (pc.connectionState === "failed") pc.restartIce();
			if (pc.connectionState === "failed" || pc.connectionState === "disconnected") this.schedulePoll(FAST_POLL_MS);
		};
		pc.onnegotiationneeded = async () => {
			try {
				slot.makingOffer = true;
				await pc.setLocalDescription();
				await this.sendSignal(peerId, "offer", pc.localDescription.toJSON());
			} catch {} finally {
				slot.makingOffer = false;
			}
		};
		pc.ondatachannel = (e) => this.attachChannel(slot, e.channel);
		if (initiator) {
			this.attachChannel(slot, pc.createDataChannel("state", {
				ordered: false,
				maxRetransmits: 0
			}));
			this.attachChannel(slot, pc.createDataChannel("reliable", { ordered: true }));
		}
		return slot;
	}
	attachChannel(slot, channel) {
		if (channel.label === "state") slot.state = channel;
		else slot.reliable = channel;
		channel.onopen = () => {
			slot.lastProgressAt = Date.now();
		};
		channel.onmessage = (e) => {
			let msg;
			try {
				msg = JSON.parse(e.data);
			} catch {
				return;
			}
			if (msg.t === "ping") {
				if (slot.state?.readyState === "open") slot.state.send(JSON.stringify({ t: "pong" }));
			} else if (msg.t === "pong") {
				if (slot.pingSentAt) {
					slot.info.rttMs = Math.round(performance.now() - slot.pingSentAt);
					slot.pingSentAt = void 0;
					this.emitPeers();
				}
			} else this.opts.onMessage?.(slot.info.id, msg.d, channel.label === "state" ? "state" : "reliable");
		};
	}
	/** Apply buffered ICE candidates once a remote description is in place. */
	async flushPendingCandidates(slot) {
		while (slot.pendingCandidates.length > 0) {
			const candidate = slot.pendingCandidates.shift();
			try {
				await slot.pc.addIceCandidate(candidate);
			} catch (err) {
				if (!slot.ignoreOffer) console.warn("[p2p] addIceCandidate failed:", err);
			}
			if (this.closed) return;
		}
	}
	async onSignal(from, kind, payload, roster) {
		if (this.closed) return;
		let slot = this.peers.get(from);
		if (!slot) {
			if (!roster.has(from)) return;
			const created = this.connectTo(from, "", false);
			if (!created) return;
			slot = created;
		}
		const polite = this.opts.selfId < from;
		try {
			if (kind === "offer" || kind === "answer") {
				const description = payload;
				const collision = kind === "offer" && (slot.makingOffer || slot.pc.signalingState !== "stable");
				slot.ignoreOffer = !polite && collision;
				if (slot.ignoreOffer) return;
				try {
					await slot.pc.setRemoteDescription(description);
				} catch (err) {
					if (kind !== "offer" || slot.recreatedForOffer) throw err;
					const attempts = slot.recoveryAttempts;
					const name = slot.info.name;
					slot.pc.close();
					this.peers.delete(from);
					const fresh = this.connectTo(from, name, false);
					if (!fresh) return;
					fresh.recoveryAttempts = attempts;
					fresh.recreatedForOffer = true;
					slot = fresh;
					await slot.pc.setRemoteDescription(description);
				}
				if (this.closed) return;
				await this.flushPendingCandidates(slot);
				if (this.closed) return;
				if (kind === "offer") {
					await slot.pc.setLocalDescription();
					if (this.closed) return;
					await this.sendSignal(from, "answer", slot.pc.localDescription.toJSON());
				}
			} else if (kind === "ice") {
				const candidate = payload;
				if (!slot.pc.remoteDescription) {
					slot.pendingCandidates.push(candidate);
					return;
				}
				try {
					await slot.pc.addIceCandidate(candidate);
				} catch (err) {
					if (!slot.ignoreOffer) console.warn("[p2p] addIceCandidate failed:", err);
				}
			}
		} catch {}
	}
	/**
	* Signals are serialized per remote peer (a candidate must never overtake
	* its SDP into the DB) and retried on failure with short backoff.
	*/
	sendSignal(to, kind, payload) {
		const next = (this.signalQueues.get(to) ?? Promise.resolve()).then(() => this.postSignal(to, kind, payload));
		this.signalQueues.set(to, next.catch(() => {}));
		return next;
	}
	async postSignal(to, kind, payload) {
		for (let attempt = 0;; attempt++) {
			if (this.closed) return;
			try {
				const res = await fetch("/api/rtc", {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						op: "signal",
						room: this.opts.room,
						from: this.opts.selfId,
						to,
						kind,
						payload
					})
				});
				if (res.ok) return;
				throw new Error(`signal POST failed: ${res.status}`);
			} catch (err) {
				if (attempt >= SIGNAL_RETRY_DELAYS_MS.length) {
					console.warn(`[p2p] signal ${kind} to ${to} failed after retries`, err);
					return;
				}
				await new Promise((r) => setTimeout(r, SIGNAL_RETRY_DELAYS_MS[attempt]));
			}
		}
	}
	pingAll() {
		const wire = JSON.stringify({ t: "ping" });
		for (const slot of this.peers.values()) {
			if (slot.state?.readyState !== "open") continue;
			const stale = slot.pingSentAt !== void 0 && performance.now() - slot.pingSentAt > 2 * PING_INTERVAL_MS;
			if (slot.pingSentAt === void 0 || stale) {
				slot.pingSentAt = performance.now();
				slot.state.send(wire);
			}
		}
	}
	/**
	* Stuck-pair recovery, piggybacked on the ping interval. A pair that has
	* made no progress for STALL_MS gets rebuilt by the dialer with a FRESH
	* RTCPeerConnection (new DTLS identity — fixes the suspend/resume
	* fingerprint wedge). After MAX_RECOVERY_ATTEMPTS the pair is terminal:
	* visible to the app as its last connectionState, ignored by fast-poll.
	*/
	watchdog() {
		if (this.closed) return;
		const now = Date.now();
		for (const [peerId, slot] of this.peers) {
			const live = slot.pc.connectionState;
			if (live !== slot.info.connectionState) {
				slot.info.connectionState = live;
				if (live === "connecting" || live === "connected") slot.lastProgressAt = now;
				this.emitPeers();
			}
			if (slot.terminal || live === "connected") continue;
			if (now - slot.lastProgressAt <= STALL_MS) continue;
			if (slot.recoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
				slot.terminal = true;
				this.emitPeers();
				continue;
			}
			slot.recoveryAttempts += 1;
			slot.lastProgressAt = now;
			if (this.opts.selfId > peerId) {
				const { name } = slot.info;
				const attempts = slot.recoveryAttempts;
				slot.pc.close();
				this.peers.delete(peerId);
				const fresh = this.connectTo(peerId, name, true);
				if (fresh) fresh.recoveryAttempts = attempts;
				this.schedulePoll(FAST_POLL_MS);
			}
		}
	}
	async readCandidateType(slot) {
		try {
			const stats = await slot.pc.getStats();
			let selected;
			stats.forEach((s) => {
				if (s.type === "candidate-pair" && s.nominated) selected = s;
			});
			const localId = selected?.localCandidateId;
			if (localId) {
				const local = stats.get(localId);
				slot.info.candidateType = local?.candidateType ?? null;
				this.emitPeers();
			}
		} catch {}
	}
	emitPeers() {
		const list = this.peerList();
		const fingerprint = JSON.stringify(list.map((p) => [
			p.id,
			p.name,
			p.connectionState,
			p.candidateType,
			p.rttMs
		]));
		if (fingerprint === this.lastPeersFingerprint) return;
		this.lastPeersFingerprint = fingerprint;
		this.opts.onPeersChanged?.(list);
	}
};
function defaultRoom() {
	if (typeof window === "undefined") return "room-ssr";
	return `room-${window.location.hostname.split(".")[0]}`.slice(0, 64);
}
function useP2PRoom(options = {}) {
	const [selfId] = (0, import_react.useState)(() => `p-${Math.random().toString(36).slice(2, 10)}`);
	const [room] = (0, import_react.useState)(() => options.room ?? defaultRoom());
	const [name] = (0, import_react.useState)(() => options.name ?? selfId);
	const [peers, setPeers] = (0, import_react.useState)([]);
	const [joined, setJoined] = (0, import_react.useState)(false);
	const roomRef = (0, import_react.useRef)(null);
	const listeners = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	(0, import_react.useEffect)(() => {
		const p2p = new P2PRoom({
			room,
			selfId,
			name,
			onPeersChanged: setPeers,
			onMessage: (from, data, channel) => {
				for (const fn of listeners.current) fn(from, data, channel);
			},
			onConnected: () => setJoined(true)
		});
		roomRef.current = p2p;
		p2p.join();
		return () => {
			roomRef.current = null;
			p2p.close();
		};
	}, [
		room,
		selfId,
		name
	]);
	return {
		selfId,
		room,
		peers,
		joined,
		broadcast: (0, import_react.useCallback)((data) => roomRef.current?.broadcast(data), []),
		send: (0, import_react.useCallback)((data, peerId) => roomRef.current?.send(data, peerId), []),
		onMessage: (0, import_react.useCallback)((fn) => {
			listeners.current.add(fn);
			return () => {
				listeners.current.delete(fn);
			};
		}, [])
	};
}
function LiveBridge({ conversation }) {
	const identity = useVault((s) => s.identity);
	const ingestRemote = useVault((s) => s.ingestRemote);
	const setLivePeers = useVault((s) => s.setLivePeers);
	const room = roomIdFromCode(conversation.roomCode ?? conversation.id);
	const p2p = useP2PRoom({
		room,
		name: identity?.callsign ?? "operator"
	});
	const keyRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		deriveRoomKey(room).then((key) => {
			if (!cancelled) keyRef.current = key;
		});
		return () => {
			cancelled = true;
		};
	}, [room]);
	(0, import_react.useEffect)(() => {
		setLivePeers(conversation.id, p2p.peers.filter((p) => p.connectionState === "connected").length);
	}, [
		conversation.id,
		p2p.peers,
		setLivePeers
	]);
	(0, import_react.useEffect)(() => {
		return p2p.onMessage((from, data, channel) => {
			if (channel !== "reliable") return;
			const envelope = data;
			(async () => {
				const key = keyRef.current;
				if (envelope.type === "msg" && envelope.payload && key) {
					try {
						const plain = await decryptText(key, envelope.payload);
						const parsed = JSON.parse(plain);
						ingestRemote(conversation.id, {
							...parsed,
							fromId: from,
							mine: false
						});
					} catch {}
					return;
				}
				if (envelope.type === "msg" && envelope.message) ingestRemote(conversation.id, {
					...envelope.message,
					fromId: from,
					mine: false
				});
			})();
		});
	}, [
		p2p,
		conversation.id,
		ingestRemote
	]);
	(0, import_react.useEffect)(() => {
		return registerLivePipe(conversation.id, (payload) => {
			const message = payload.message;
			(async () => {
				const key = keyRef.current;
				if (key) {
					const sealed = await encryptText(key, JSON.stringify(message));
					p2p.send({
						type: "msg",
						payload: sealed
					});
				} else p2p.send({
					type: "msg",
					message
				});
			})();
		});
	}, [conversation.id, p2p]);
	return null;
}
var rails = [
	{
		id: "inbox",
		label: "Chats",
		icon: Inbox
	},
	{
		id: "live",
		label: "Channels",
		icon: Radio
	},
	{
		id: "drops",
		label: "Drops",
		icon: ShieldAlert
	},
	{
		id: "archive",
		label: "Archive",
		icon: Archive
	},
	{
		id: "vault",
		label: "Vault",
		icon: Settings
	}
];
function BottomNav() {
	const rail = useVault((s) => s.rail);
	const setRail = useVault((s) => s.setRail);
	const setActive = useVault((s) => s.setActive);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "flex h-16 shrink-0 items-stretch border-t border-border bg-surface pb-[env(safe-area-inset-bottom)]",
		children: rails.map((item) => {
			const Icon = item.icon;
			const active = rail === item.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				"aria-label": item.label,
				onClick: () => {
					setRail(item.id);
					if (item.id === "vault") setActive(null);
				},
				className: cn("flex flex-1 flex-col items-center justify-center gap-1 text-[11px] font-medium", active ? "text-fg" : "text-subtle"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: cn("size-5", active && "text-ice") }), item.label]
			}, item.id);
		})
	});
}
var chips = [
	{
		id: "inbox",
		label: "All"
	},
	{
		id: "live",
		label: "Channels"
	},
	{
		id: "drops",
		label: "Drops"
	},
	{
		id: "archive",
		label: "Archive"
	}
];
function ConversationList({ onInvite }) {
	const conversations = useVault((s) => s.conversations);
	const activeId = useVault((s) => s.activeId);
	const setActive = useVault((s) => s.setActive);
	const rail = useVault((s) => s.rail);
	const setRail = useVault((s) => s.setRail);
	const query = useVault((s) => s.query);
	const setQuery = useVault((s) => s.setQuery);
	const filtered = conversations.filter((c) => {
		if (rail === "archive") return c.archived;
		if (c.archived) return false;
		if (rail === "live") return c.kind === "live";
		if (rail === "drops") return c.kind === "dead-drop";
		return true;
	}).filter((c) => {
		if (!query.trim()) return true;
		const q = query.toLowerCase();
		return c.title.toLowerCase().includes(q) || c.lastPreview.toLowerCase().includes(q);
	}).sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.lastAt - a.lastAt);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "relative flex h-full min-w-0 flex-col bg-surface md:border-r md:border-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "px-4 pb-2 pt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium tracking-[0.16em] text-ice uppercase",
					children: "GhostWire for Android"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-medium tracking-tight",
					children: rail === "live" ? "Sealed channels" : rail === "drops" ? "Dead drops" : rail === "archive" ? "Archive" : "Conversations"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1 overflow-x-auto px-3 pb-2",
				children: chips.map((chip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setRail(chip.id),
					className: cn("h-8 shrink-0 rounded-full px-3 text-xs font-medium", rail === chip.id ? "bg-accent text-accent-fg" : "bg-elevated text-muted"),
					children: chip.label
				}, chip.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-3 pb-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "relative block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: query,
						onChange: (e) => setQuery(e.target.value),
						placeholder: "Search conversations",
						className: "h-11 w-full rounded-full bg-elevated pl-10 pr-4 text-sm text-fg placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ice/50"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-y-auto pb-20",
				children: filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-4 py-8 text-sm text-muted",
					children: rail === "live" ? "No sealed channels yet. Tap + to invite a peer — no Wire servers involved." : "No conversations."
				}) : filtered.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConversationRow, {
					conversation: c,
					active: c.id === activeId,
					onSelect: () => setActive(c.id)
				}, c.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onInvite,
				"aria-label": "New sealed channel",
				className: "absolute bottom-5 right-4 flex size-14 items-center justify-center rounded-full bg-accent text-accent-fg shadow-[var(--shadow-border)] transition-transform duration-150 active:scale-[0.96]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-6" })
			})
		]
	});
}
function ConversationRow({ conversation, active, onSelect }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick: onSelect,
		className: cn("flex min-h-16 w-full items-center gap-3 px-4 py-2.5 text-left transition-colors duration-150", active ? "bg-elevated" : "hover:bg-elevated/60", conversation.knocked && "knock-flash"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonMark, {
			name: conversation.title,
			hue: conversation.hue,
			verified: conversation.verified,
			size: "md"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate text-[15px] font-medium",
					children: conversation.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-auto shrink-0 text-[11px] tabular-nums text-subtle",
					children: formatListTime(conversation.lastAt)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "mt-0.5 flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate text-[13px] text-muted",
					children: conversation.lastPreview
				}), conversation.unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-auto inline-flex min-w-5 items-center justify-center rounded-full bg-accent px-1.5 text-[11px] font-medium text-accent-fg",
					children: conversation.unread
				}) : null]
			})]
		})]
	});
}
function TooltipProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Provider, {
		delayDuration: 250,
		skipDelayDuration: 80,
		children
	});
}
function useMobile() {
	const [mobile, setMobile] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(max-width: 767px)");
		const apply = () => setMobile(mq.matches);
		apply();
		mq.addEventListener("change", apply);
		return () => mq.removeEventListener("change", apply);
	}, []);
	return mobile;
}
function AppShell() {
	const phase = useVault((s) => s.phase);
	const boot = useVault((s) => s.boot);
	const purgeExpired = useVault((s) => s.purgeExpired);
	const settings = useVault((s) => s.settings);
	const lock = useVault((s) => s.lock);
	const hasPin = useVault((s) => s.hasPin);
	const rail = useVault((s) => s.rail);
	const activeId = useVault((s) => s.activeId);
	const setActive = useVault((s) => s.setActive);
	const conversations = useVault((s) => s.conversations);
	const [inviteOpen, setInviteOpen] = (0, import_react.useState)(false);
	const [hidden, setHidden] = (0, import_react.useState)(false);
	const mobile = useMobile();
	(0, import_react.useEffect)(() => {
		boot();
	}, [boot]);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(purgeExpired, 5e3);
		return () => window.clearInterval(id);
	}, [purgeExpired]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "l" && hasPin) {
				e.preventDefault();
				lock();
			}
			if (settings.screenshotShield && e.key === "PrintScreen") {
				e.preventDefault();
				toast("Capture blocked by vault policy");
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		hasPin,
		lock,
		settings.screenshotShield
	]);
	(0, import_react.useEffect)(() => {
		if (!settings.screenshotShield) return;
		const onVis = () => setHidden(document.hidden);
		document.addEventListener("visibilitychange", onVis);
		return () => document.removeEventListener("visibilitychange", onVis);
	}, [settings.screenshotShield]);
	if (phase === "boot") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-bg text-sm text-muted",
		children: "Opening vault…"
	});
	if (phase === "onboarding") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Onboarding, {});
	if (phase === "locked") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockScreen, {});
	const live = conversations.filter((c) => c.kind === "live" && c.roomCode);
	const inChat = Boolean(activeId) && rail !== "vault";
	const showList = !mobile || !inChat;
	const showChat = !mobile && rail !== "vault" || mobile && inChat;
	const showVault = rail === "vault";
	const showNav = !mobile || !inChat;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex h-dvh flex-col overflow-hidden bg-bg text-fg", settings.screenshotShield && "vault-shield", hidden && "vault-blur"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1",
				children: [
					showList && !showVault ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-full min-w-0 md:w-[22rem] md:shrink-0 lg:w-[26rem]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConversationList, { onInvite: () => setInviteOpen(true) })
					}) : null,
					showVault ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "min-w-0 flex-1 overflow-y-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VaultPanel, {})
					}) : null,
					showChat ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "min-w-0 flex-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatPane, { onBack: mobile ? () => setActive(null) : void 0 })
					}) : null
				]
			}),
			showNav ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {}) : null,
			live.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveBridge, { conversation: c }, c.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InviteDialog, {
				open: inviteOpen,
				onOpenChange: setInviteOpen
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CallOverlay, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "bottom-center",
				toastOptions: { className: "bg-panel text-fg border border-border" }
			})
		]
	}) });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { Home as component };
