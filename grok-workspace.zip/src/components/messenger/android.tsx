import { Battery, Lock, Wifi } from "lucide-react";
import { GhostMark } from "@/components/messenger/mark";
import { useVault } from "@/lib/messenger/store";

export function StatusBar() {
  const shield = useVault((s) => s.settings.screenshotShield);
  const now = new Date();
  const time = now.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });

  return (
    <div className="flex h-7 shrink-0 items-center justify-between bg-bg px-3 text-[11px] tabular-nums text-muted">
      <span>{time}</span>
      <span className="flex items-center gap-1.5 font-medium tracking-[0.14em] text-subtle uppercase">
        <GhostMark className="size-3" />
        GhostWire
      </span>
      <span className="flex items-center gap-2">
        {shield ? <Lock className="size-3 text-ice" /> : null}
        <Wifi className="size-3" />
        <Battery className="size-3.5" />
      </span>
    </div>
  );
}
