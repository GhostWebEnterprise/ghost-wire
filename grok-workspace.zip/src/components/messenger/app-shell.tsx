import { useEffect, useState } from "react";
import { Toaster, toast } from "sonner";
import { StatusBar } from "@/components/messenger/android";
import { CallOverlay, InviteDialog, LockScreen, Onboarding, VaultPanel } from "@/components/messenger/overlays";
import { ChatPane } from "@/components/messenger/chat-pane";
import { LiveBridge } from "@/components/messenger/live-bridge";
import { BottomNav, ConversationList } from "@/components/messenger/sidebar";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useVault } from "@/lib/messenger/store";
import { cn } from "@/lib/utils";

function useMobile() {
  const [mobile, setMobile] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 767px)");
    const apply = () => setMobile(mq.matches);
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);
  return mobile;
}

export function AppShell() {
  const phase = useVault((s) => s.phase);
  const boot = useVault((s) => s.boot);
  const purgeExpired = useVault((s) => s.purgeExpired);
  const settings = useVault((s) => s.settings);
  const lock = useVault((s) => s.lock);
  const hasPin = useVault((s) => s.hasPin);
  const rail = useVault((s) => s.rail);
  const activeId = useVault((s) => s.activeId);
  const setActive = useVault((s) => s.setActive);
  const conversations = useVault((s) => s.conversations);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [hidden, setHidden] = useState(false);
  const mobile = useMobile();

  useEffect(() => {
    boot();
  }, [boot]);

  useEffect(() => {
    const id = window.setInterval(purgeExpired, 5000);
    return () => window.clearInterval(id);
  }, [purgeExpired]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "l" && hasPin) {
        e.preventDefault();
        void lock();
      }
      if (settings.screenshotShield && e.key === "PrintScreen") {
        e.preventDefault();
        toast("Capture blocked by vault policy");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [hasPin, lock, settings.screenshotShield]);

  useEffect(() => {
    if (!settings.screenshotShield) return;
    const onVis = () => setHidden(document.hidden);
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [settings.screenshotShield]);

  if (phase === "boot") {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-bg text-sm text-muted">
        Opening vault…
      </div>
    );
  }
  if (phase === "onboarding") return <Onboarding />;
  if (phase === "locked") return <LockScreen />;

  const live = conversations.filter((c) => c.kind === "live" && c.roomCode);
  const inChat = Boolean(activeId) && rail !== "vault";
  const showList = !mobile || !inChat;
  const showChat = (!mobile && rail !== "vault") || (mobile && inChat);
  const showVault = rail === "vault";
  const showNav = !mobile || !inChat;

  return (
    <TooltipProvider>
      <div
        className={cn(
          "flex h-dvh flex-col overflow-hidden bg-bg text-fg",
          settings.screenshotShield && "vault-shield",
          hidden && "vault-blur",
        )}
      >
        <StatusBar />
        <div className="flex min-h-0 flex-1">
          {showList && !showVault ? (
            <div className="w-full min-w-0 md:w-[22rem] md:shrink-0 lg:w-[26rem]">
              <ConversationList onInvite={() => setInviteOpen(true)} />
            </div>
          ) : null}
          {showVault ? (
            <div className="min-w-0 flex-1 overflow-y-auto">
              <VaultPanel />
            </div>
          ) : null}
          {showChat ? (
            <div className="min-w-0 flex-1">
              <ChatPane onBack={mobile ? () => setActive(null) : undefined} />
            </div>
          ) : null}
        </div>
        {showNav ? <BottomNav /> : null}
        {live.map((c) => (
          <LiveBridge key={c.id} conversation={c} />
        ))}
        <InviteDialog open={inviteOpen} onOpenChange={setInviteOpen} />
        <CallOverlay />
        <Toaster
          theme="dark"
          position="bottom-center"
          toastOptions={{
            className: "bg-panel text-fg border border-border",
          }}
        />
      </div>
    </TooltipProvider>
  );
}
